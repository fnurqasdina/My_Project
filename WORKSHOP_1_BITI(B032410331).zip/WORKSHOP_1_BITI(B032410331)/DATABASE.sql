-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2025 at 01:55 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vmms`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustomerID` varchar(50) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Address` text DEFAULT NULL,
  `PhoneNumber` varchar(15) NOT NULL,
  `Email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustomerID`, `Name`, `Address`, `PhoneNumber`, `Email`) VALUES
('Cust001', 'Zamir', 'Penang', '0162398710', 'zamir@gmail.com'),
('Cust002', 'Farhan', 'Sabak Bernam', '0189234543', 'ff@gmail.com'),
('Cust003', 'Addin', 'Melaka', '0146349298', 'addin@gmail.com'),
('Cust004', 'Thariq', 'Kuala Lumpur', '0198900008', 'thariq@gmail.com'),
('Cust005', 'Azlan', 'Penang', '01156781212', 'azlan@gmail.com'),
('Cust007', 'Rashid', 'Perlis', '0167890101', 'rashid@gmail.com'),
('Cust008', 'Aiman', 'Melaka', '0126139671', 'aiman@gmai.com'),
('Cust009', 'Dina', 'Melaka', '0123456789', 'dina@gmail.com'),
('Cust010', 'Lizza', 'Johor', '0129999999', 'lizza@gmail.com'),
('Cust011', 'Tester', 'UTeM', '0199999999', 'tester@gmail.com'),
('Cust012', 'Ayden', 'Selangor', '01189002312', 'ayden@gmail.com'),
('Cust014', 'Farouk', 'Melaka', '01134549089', 'farouk@gmail.com'),
('Cust015', 'Shahirah', 'Johor', '0162398900', 'shahirah_@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `MaintenanceID` varchar(255) NOT NULL,
  `VehicleID` varchar(255) NOT NULL,
  `ServiceDate` date DEFAULT NULL,
  `ServiceType` varchar(100) DEFAULT NULL,
  `Cost` decimal(10,2) DEFAULT NULL,
  `Quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `maintenance`
--

INSERT INTO `maintenance` (`MaintenanceID`, `VehicleID`, `ServiceDate`, `ServiceType`, `Cost`, `Quantity`) VALUES
('Maint001', 'Vehicle001', '2025-01-07', 'Tyre Replacement', 100.00, 1),
('Maint002', 'Vehicle001', '2025-01-07', 'Oil Change', 900.00, 1),
('Maint003', 'Vehicle001', '2025-01-07', 'Tyre Replacement', 211.00, 1),
('Maint004', 'Vehicle005', '2025-01-07', 'Oil Change', 50.00, 1),
('Maint005', 'Vehicle002', '2025-01-13', 'Oil Change', 55.00, 1),
('Maint006', 'Vehicle002', '2025-01-13', 'Oil Change', 55.00, 1),
('Maint007', 'Vehicle002', '2025-01-13', 'Tyre Replacement', 450.00, 1),
('Maint008', 'Vehicle002', '2025-01-13', 'Wiper', 35.00, 1),
('Maint009', 'Vehicle002', '2025-01-13', 'Battery', 550.00, 1),
('Maint010', 'Vehicle002', '2025-01-14', 'Break', 35.00, 1),
('Maint011', 'Vehicle002', '2025-01-14', 'Aircond', 200.00, 1),
('Maint012', 'Vehicle002', '2025-01-14', 'Tyre', 350.00, 1),
('Maint013', 'Vehicle006', '2025-01-14', 'wiring', 200.00, 1),
('Maint014', 'Vehicle006', '2025-01-14', 'tyre', 350.00, 1),
('Maint015', 'Vehicle003', '2025-01-14', 'oil change', 50.00, 1),
('Maint016', 'Vehicle003', '2025-01-14', 'tyre replacement', 350.00, 1),
('Maint017', 'Vehicle006', '2025-01-20', 'tyre', 100.00, 3),
('Maint018', 'Vehicle006', '2025-01-20', 'oil', 55.00, 2),
('Maint019', 'Vehicle007', '2025-01-20', 'oil change', 50.00, 2),
('Maint020', 'Vehicle008', '2025-01-21', 'battery', 250.00, 1),
('Maint021', 'Vehicle001', '2025-01-22', 'Engine Check', 1000.00, 1),
('Maint022', 'Vehicle001', '2025-01-22', 'Oil Change', 100.00, 1),
('Maint023', 'Vehicle001', '2025-01-22', 'Engine Check', 350.00, 250),
('Maint024', 'Vehicle001', '2025-01-22', 'tyre', 250.00, 2),
('Maint025', 'Vehicle001', '2025-01-22', 'oil change', 100.00, 1),
('Maint026', 'Vehicle009', '2025-01-23', 'wiring', 150.00, 5),
('Maint027', 'Vehicle009', '2025-01-23', 'tyre', 200.00, 4),
('Maint028', 'Vehicle009', '2025-01-23', 'tyre', 150.00, 3),
('Maint029', 'Vehicle009', '2025-01-23', 'oil', 90.00, 1),
('Maint030', 'Vehicle010', '2025-01-24', 'tyre', 150.00, 2),
('Maint031', 'Vehicle010', '2025-01-24', 'oil', 50.00, 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('staff','admin') NOT NULL DEFAULT 'staff'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(3, 'bob_jones', 'bobpassword', 'staff'),
(4, 'susan_lee', 'susan1234', 'staff'),
(5, 'michael_brown', 'mike2025', 'staff'),
(6, 'fqasdina_', 'fatinqasdina', 'staff'),
(7, 'fqasdina', 'Fatin03_', 'staff'),
(8, 'qasdinarashid', 'Qasdina03_', 'staff'),
(9, 'syakirahrashid', 'Syakirah99_', 'staff'),
(10, 'FatinNurqasdina', 'FATINqasdina03_', 'admin'),
(13, 'YusraHaziqah', 'YUSRAhaziqah03_', 'admin'),
(14, 'Sumaiyah', 'Sumaiyah03_', 'staff'),
(15, '12345', 'Khalizah03_', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `VehicleID` varchar(36) NOT NULL,
  `CustomerID` varchar(50) DEFAULT NULL,
  `Color` varchar(50) DEFAULT NULL,
  `TypeCar` varchar(50) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `LicensePlate` varchar(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`VehicleID`, `CustomerID`, `Color`, `TypeCar`, `Year`, `LicensePlate`) VALUES
('Vehicle001', 'Cust001', 'Forest', 'BMW', 2023, 'BMW0003'),
('Vehicle002', 'Cust004', 'Black', 'Saga', 2020, 'THQ0702'),
('Vehicle003', 'Cust002', 'Red', 'Civic', 2021, 'NON2000'),
('Vehicle005', 'Cust003', 'Pink', 'Saga', 2020, 'MDQ7028'),
('Vehicle006', 'Cust005', 'Blue', 'Preve', 2015, 'AZL1975'),
('Vehicle007', 'Cust008', 'Green', 'Saga', 2017, 'AIM2017'),
('Vehicle008', 'Cust007', 'Grey', 'Wira', 2010, 'ACM3434'),
('Vehicle009', 'Cust012', 'Grey', 'Saga', 2014, 'AYD2003'),
('Vehicle010', 'Cust015', 'Black', 'Saga', 2018, 'YSY3030');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustomerID`),
  ADD UNIQUE KEY `PhoneNumber` (`PhoneNumber`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`MaintenanceID`),
  ADD KEY `VehicleID` (`VehicleID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`VehicleID`),
  ADD UNIQUE KEY `LicensePlate` (`LicensePlate`),
  ADD KEY `CustomerID` (`CustomerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
