#include <iostream>
#include <ctime>
#include <mysql.h>
#include <string>
#include <regex>
#include <iomanip> // For table formatting
#include <limits> // For numeric_limits
#include <regex> // For regex validation
#include <conio.h>
#include <fstream>
#include <windows.h>  // Include the windows.h header for Windows API
#undef max       // Fix macro conflict with max


using namespace std;

MYSQL* conn; // MySQL connection handle
string currentUserRole = "guest"; // Global variable for user role

// Connect to Database
void connectDatabase() {
    conn = mysql_init(0);
    conn = mysql_real_connect(conn, "localhost", "root", "", "vmms", 3306, NULL, 0);
    if (conn) {
        cout << "Connected to the database." << endl;
    }
    else {
        cerr << "Failed to connect to database!" << endl;
        exit(1);
    }
}

// Function to validate username format (alphanumeric, 5-15 characters)
bool isValidUsername(const string& username) {
    const regex usernamePattern("^[a-zA-Z0-9]{5,15}$");
    return regex_match(username, usernamePattern);
}

// Function to validate password format (at least 8 characters, one uppercase, one lowercase, one number)
bool isValidPassword(const string& password) {
    const regex passwordPattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$");
    return regex_match(password, passwordPattern);
}

// Function to check if username already exists
bool isDuplicateUsername(const string& username) {
    string query = "SELECT COUNT(*) FROM users WHERE username = '" + username + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    int count = atoi(row[0]); // Get the count of rows with the same username
    mysql_free_result(result);

    return count > 0; // Return true if a duplicate is found
}

bool createAdminUser() {
    string username, password;

    cout << "===== Create Admin User =====" << endl;

    // Username input and validation
    while (true) {
        cout << "Enter a Username (5-15 alphanumeric characters): ";
        cin >> username;
        if (!isValidUsername(username)) {
            cerr << "Error: Invalid username format. Please follow the rules." << endl;
        }
        else if (isDuplicateUsername(username)) {
            cerr << "Error: Username already exists. Please choose a different username." << endl;
        }
        else {
            break; // Exit the loop if username is valid and not a duplicate
        }
    }

    // Password input and masking
    while (true) {
        cout << "Enter a Password (at least 8 characters, one uppercase, one lowercase, one number): ";
        password = "";  // Clear previous input
        char ch;
        while ((ch = _getch()) != 13) {  // 13 is ASCII for Enter key
            if (ch == 8) {  // 8 is ASCII for backspace
                if (password.length() > 0) {
                    password.pop_back();
                    cout << "\b \b";  // Erase last character on screen
                }
            }
            else {
                password.push_back(ch);
                cout << "*";  // Display '*' as password character
            }
        }
        cout << endl;

        if (!isValidPassword(password)) {
            cerr << "Error: Invalid password format. Please follow the rules." << endl;

        }
        else {
            break;
        }
    }

    // Insert the new user into the database with a default role of 'staff'
    string query = "INSERT INTO users (username, password, role) VALUES ('" + username + "', '" + password + "', 'admin')";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }
    else {
        cout << "Admin user created successful! You can now log in." << endl;
        return true;
    }
}

// Function for user sign-up
bool signUp() {
    string username, password;

    cout << "===== Sign Up =====" << endl;

    // Username input and validation
    while (true) {
        cout << "Enter a Username (5-15 alphanumeric characters): ";
        cin >> username;
        if (!isValidUsername(username)) {
            cerr << "Error: Invalid username format. Please follow the rules." << endl;
        }
        else if (isDuplicateUsername(username)) {
            cerr << "Error: Username already exists. Please choose a different username." << endl;
        }
        else {
            break; // Exit the loop if username is valid and not a duplicate
        }
    }

    // Password input and masking
    while (true) {
        cout << "Enter a Password (at least 8 characters, one uppercase, one lowercase, one number): ";
        password = "";  // Clear previous input
        char ch;
        while ((ch = _getch()) != 13) {  // 13 is ASCII for Enter key
            if (ch == 8) {  // 8 is ASCII for backspace
                if (password.length() > 0) {
                    password.pop_back();
                    cout << "\b \b";  // Erase last character on screen
                }
            }
            else {
                password.push_back(ch);
                cout << "*";  // Display '*' as password character
            }
        }
        cout << endl;

        if (!isValidPassword(password)) {
            cerr << "Error: Invalid password format. Please follow the rules." << endl;

        }
        else {
            break;
        }
    }

    // Insert the new user into the database
    string query = "INSERT INTO users (username, password) VALUES ('" + username + "', '" + password + "')";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }
    else {
        cout << "Sign up successful! You can now log in." << endl;
        return true;
    }
}

bool login() {
    string username, password;

    // Prompt user for credentials
    cout << "===== Login =====" << endl;
    cout << "Enter Username: ";
    cin >> username;
    cout << "Enter Password: ";

    // Input password while masking with '*'
    char ch;
    while ((ch = _getch()) != 13) {  // 13 is ASCII for Enter key
        if (ch == 8) {  // 8 is ASCII for backspace
            if (password.length() > 0) {
                password.pop_back();
                cout << "\b \b";  // Erase last character on screen
            }
        }
        else {
            password.push_back(ch);
            cout << "*";  // Display '*' as password character
        }
    }
    cout << endl;

    // Query the database to verify credentials and fetch the user's role
    string query = "SELECT role FROM users WHERE username = '" + username + "' AND password = '" + password + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    // Check if any row matches the credentials
    MYSQL_ROW row = mysql_fetch_row(result);
    bool loginSuccess = row != nullptr;

    if (loginSuccess) {
        currentUserRole = row[0];  // Store the user's role globally
        cout << "Login successful! Welcome, " << username << " (Role: " << currentUserRole << ")!" << endl;
    }
    else {
        cerr << "Invalid username or password. Please try again." << endl;
    }

    mysql_free_result(result);
    return loginSuccess;
}

// Display Data in Table Format with Incremental "No."
void displayAllUsers() {
    if (currentUserRole != "admin") {
        cout << "Access denied. This function is for admin users only." << endl;
        return;
    }
    string query = "SELECT * FROM users";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_ROW row;
    unsigned int numFields = mysql_num_fields(result);
    MYSQL_FIELD* fields = mysql_fetch_fields(result);

    // Determine the maximum width for each column
    vector<size_t> colWidths(numFields, 0);
    for (unsigned int i = 0; i < numFields; ++i) {
        colWidths[i] = max(colWidths[i], strlen(fields[i].name)); // Column name length
    }

    while ((row = mysql_fetch_row(result))) {
        for (unsigned int i = 0; i < numFields; ++i) {
            colWidths[i] = max(colWidths[i], row[i] ? strlen(row[i]) : 4); // Length of data or "NULL"
        }
    }
    mysql_data_seek(result, 0); // Reset the result pointer to start

    // Print table header with "No." column
    cout << "+";
    cout << string(5, '-') << "+"; // For the "No." column
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    // Print "No." and column names
    cout << "| No. |";
    for (unsigned int i = 0; i < numFields; ++i) {
        cout << " " << setw(colWidths[i]) << left << fields[i].name << " |";
    }
    cout << endl;

    // Print the separator line
    cout << "+";
    cout << string(5, '-') << "+"; // For the "No." column
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    // Print table rows with incremental number
    int rowNum = 1; // Row counter for "No." column
    while ((row = mysql_fetch_row(result))) {
        cout << "|";
        cout << " " << setw(3) << left << rowNum << " |";  // Print the "No." column with incremental number
        for (unsigned int i = 0; i < numFields; ++i) {
            string cellValue = (row[i] ? row[i] : "NULL");
            if (cellValue.length() > colWidths[i]) {
                cellValue = cellValue.substr(0, colWidths[i] - 3) + "...";
            }
            cout << " " << setw(colWidths[i]) << left << cellValue << " |";
        }
        cout << endl;
        rowNum++; // Increment the row number
    }

    // Print the final separator line
    cout << "+";
    cout << string(5, '-') << "+"; // For the "No." column
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    mysql_free_result(result);
}

void addUser() {
    if (currentUserRole != "admin") {
        cout << "Access denied. This function is for admin users only." << endl;
        return;
    }
    string username, password, role;

    cout << "===== Add User =====" << endl;

    // Username input and validation
    while (true) {
        cout << "Enter a Username (5-15 alphanumeric characters): ";
        cin >> username;
        if (!isValidUsername(username)) {
            cerr << "Error: Invalid username format. Please follow the rules." << endl;
        }
        else if (isDuplicateUsername(username)) {
            cerr << "Error: Username already exists. Please choose a different username." << endl;
        }
        else {
            break; // Exit the loop if username is valid and not a duplicate
        }
    }

    // Password input and masking
    while (true) {
        cout << "Enter a Password (at least 8 characters, one uppercase, one lowercase, one number): ";
        password = "";  // Clear previous input
        char ch;
        while ((ch = _getch()) != 13) {  // 13 is ASCII for Enter key
            if (ch == 8) {  // 8 is ASCII for backspace
                if (password.length() > 0) {
                    password.pop_back();
                    cout << "\b \b";  // Erase last character on screen
                }
            }
            else {
                password.push_back(ch);
                cout << "*";  // Display '*' as password character
            }
        }
        cout << endl;

        if (!isValidPassword(password)) {
            cerr << "Error: Invalid password format. Please follow the rules." << endl;

        }
        else {
            break;
        }
    }

    // Role input
    while (true) {
        cout << "Enter Role (staff or admin): ";
        cin >> role;
        if (role == "staff" || role == "admin") {
            break;
        }
        else {
            cerr << "Error: Invalid role. Please enter 'staff' or 'admin'." << endl;
        }
    }

    // Insert the new user into the database
    string query = "INSERT INTO users (username, password, role) VALUES ('" + username + "', '" + password + "', '" + role + "')";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }
    else {
        cout << "User added successfully!" << endl;
    }
    displayAllUsers();
}

void updateUser() {
    if (currentUserRole != "admin") {
        cout << "Access denied. This function is for admin users only." << endl;
        return;
    }
    string username, role;
    char choice;

    cout << "Enter username of user to update: ";
    cin >> username;


    // Menu for selecting fields to update
    cout << "\n===== Select fields to update =====" << endl;
    cout << "a. Role" << endl;
    cout << "Enter your choice (a), or press any other key to skip : ";
    cin >> choice;


    // Collect new values and build the UPDATE query based on user selections
    string updateQuery = "UPDATE users SET ";
    vector<string> updates;
    cin.ignore(); // consume newline
    if (tolower(choice) == 'a') {
        // Role input
        while (true) {
            cout << "Enter New Role (staff or admin): ";
            cin >> role;
            if (role == "staff" || role == "admin") {
                updates.push_back("role = '" + role + "'");
                break;
            }
            else {
                cerr << "Error: Invalid role. Please enter 'staff' or 'admin'." << endl;
            }
        }
    }
    if (updates.empty()) {
        cout << "No fields to update." << endl;
        return;
    }
    // Append updates to the base update query
    for (size_t i = 0; i < updates.size(); ++i) {
        updateQuery += updates[i];
        if (i < updates.size() - 1) {
            updateQuery += ", ";
        }
    }

    updateQuery += " WHERE username = '" + username + "'";

    if (mysql_query(conn, updateQuery.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
    }
    else {
        cout << "User updated successfully!" << endl;
    }
    displayAllUsers();
}

void deleteUser() {
    if (currentUserRole != "admin") {
        cout << "Access denied. This function is for admin users only." << endl;
        return;
    }
    string username;
    cout << "Enter username of user to delete: ";
    cin >> username;

    string query = "DELETE FROM users WHERE username = '" + username + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
    }
    else {
        cout << "User deleted successfully!" << endl;
    }
    displayAllUsers();
}

// Display Data in Table Format with Incremental "No."
void displayData(const string& tableName) {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string query = "SELECT * FROM " + tableName;
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_ROW row;
    unsigned int numFields = mysql_num_fields(result);
    MYSQL_FIELD* fields = mysql_fetch_fields(result);

    // Determine the maximum width for each column
    vector<size_t> colWidths(numFields, 0);
    for (unsigned int i = 0; i < numFields; ++i) {
        colWidths[i] = max(colWidths[i], strlen(fields[i].name)); // Column name length
    }

    while ((row = mysql_fetch_row(result))) {
        for (unsigned int i = 0; i < numFields; ++i) {
            colWidths[i] = max(colWidths[i], row[i] ? strlen(row[i]) : 4); // Length of data or "NULL"
        }
    }
    mysql_data_seek(result, 0); // Reset the result pointer to start

    // Print table header with "No." column
    cout << "+";
    cout << string(5, '-') << "+"; // For the "No." column
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    // Print "No." and column names
    cout << "| No. |";
    for (unsigned int i = 0; i < numFields; ++i) {
        cout << " " << setw(colWidths[i]) << left << fields[i].name << " |";
    }
    cout << endl;

    // Print the separator line
    cout << "+";
    cout << string(5, '-') << "+"; // For the "No." column
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    // Print table rows with incremental number
    int rowNum = 1; // Row counter for "No." column
    while ((row = mysql_fetch_row(result))) {
        cout << "|";
        cout << " " << setw(3) << left << rowNum << " |";  // Print the "No." column with incremental number
        for (unsigned int i = 0; i < numFields; ++i) {
            string cellValue = (row[i] ? row[i] : "NULL");
            if (cellValue.length() > colWidths[i]) {
                cellValue = cellValue.substr(0, colWidths[i] - 3) + "...";
            }
            cout << " " << setw(colWidths[i]) << left << cellValue << " |";
        }
        cout << endl;
        rowNum++; // Increment the row number
    }

    // Print the final separator line
    cout << "+";
    cout << string(5, '-') << "+"; // For the "No." column
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    mysql_free_result(result);
}

// Validate Email
bool isValidEmail(const string& email) {
    const regex emailPattern(R"((\w+)(\.\w+)*@(\w+)(\.\w+)+)");
    return regex_match(email, emailPattern);
}

// Function to validate phone number length and digits
bool isValidPhoneNumber(const string& phone) {
    return (phone.length() >= 10 && phone.length() <= 11) && phone.find_first_not_of("0123456789") == string::npos;
}

// Validate CustomerID format ("Cust" followed by exactly 3 digits)
bool isValidCustomerID(const string& customerID) {
    const regex customerIDPattern(R"(^Cust\d{3}$)");
    return regex_match(customerID, customerIDPattern);
}

// Check if CustomerID already exists in the database
bool isDuplicateCustomerID(const string& customerID) {
    string query = "SELECT COUNT(*) FROM Customer WHERE CustomerID = '" + customerID + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    int count = atoi(row[0]); // Get the count of rows with the same CustomerID
    mysql_free_result(result);

    return count > 0; // Return true if a duplicate is found
}

// Add customer function with CustomerID format and duplicate checking
void addCustomer() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string customerID, name, address, phone, email;

    // Clear input buffer
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    // Prompt user for CustomerID
    while (true) {
        cout << "Enter CustomerID (example: Cust001): ";
        getline(cin, customerID);

        // Validate CustomerID format
        if (!isValidCustomerID(customerID)) {
            cerr << "Error: Invalid CustomerID format. It must start with 'Cust' followed by exactly 3 digits (e.g., Cust001)." << endl;
        }
        else if (isDuplicateCustomerID(customerID)) {
            cerr << "Error: CustomerID already exists. Please choose a different ID." << endl;
        }
        else {
            break; // Exit the loop if CustomerID is valid and not a duplicate
        }
    }

    cout << "Enter Name: ";
    getline(cin, name);
    cout << "Enter Address: ";
    getline(cin, address);

    // Validate phone number length and digits
    while (true) {
        cout << "Enter Phone Number (10-11 digits): ";
        getline(cin, phone);
        if (!isValidPhoneNumber(phone)) {
            cerr << "Error: Phone Number must be 10 or 11 digits. Please try again." << endl;
        }
        else {
            break; // Exit the loop if phone number is valid
        }
    }

    // Validate email format
    while (true) {
        cout << "Enter Email: ";
        getline(cin, email);
        if (!isValidEmail(email)) {
            cerr << "Error: Invalid email format. Please try again." << endl;
        }
        else {
            break; // Exit the loop if email is valid
        }
    }

    // Insert the data into the database
    string query = "INSERT INTO Customer (CustomerID, Name, Address, PhoneNumber, Email) VALUES ('" + customerID + "', '" + name + "', '" + address + "', '" + phone + "', '" + email + "')";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
    }
    else {
        cout << "Customer added successfully!" << endl;
        displayData("customer");
    }
}

// Update customer
void updateCustomer() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string customerID, name, address, phone, email;
    char choice;

    cout << "Enter Customer ID to Update: ";
    cin >> customerID;

    // Menu for selecting fields to update
    cout << "\n===== Select fields to update =====" << endl;
    cout << "a. Name" << endl;
    cout << "b. Address" << endl;
    cout << "c. Phone Number" << endl;
    cout << "d. Email" << endl;
    cout << "Enter your choice (a, b, c, d), or press any other key to skip : ";
    cin >> choice;

    // Collect new values and build the UPDATE query based on user selections
    string updateQuery = "UPDATE Customer SET ";
    vector<string> updates;

    cin.ignore(); // consume newline

    if (tolower(choice) == 'a') {
        cout << "Enter New Name: ";
        getline(cin, name);
        updates.push_back("Name = '" + name + "'");
    }
    if (tolower(choice) == 'b') {
        cout << "Enter New Address: ";
        getline(cin, address);
        updates.push_back("Address = '" + address + "'");
    }
    if (tolower(choice) == 'c') {
        // Validate phone number length and digits
        while (true) {
            cout << "Enter New Phone Number (10-11 digits): ";
            getline(cin, phone);
            if (!isValidPhoneNumber(phone)) {
                cerr << "Error: Phone Number must be 10 or 11 digits. Please try again." << endl;
            }
            else {
                updates.push_back("PhoneNumber = '" + phone + "'");
                break; // Exit the loop if phone number is valid
            }
        }
    }
    if (tolower(choice) == 'd') {
        // Validate email format
        while (true) {
            cout << "Enter New Email: ";
            getline(cin, email);
            if (!isValidEmail(email)) {
                cerr << "Error: Invalid email format. Please try again." << endl;
            }
            else {
                updates.push_back("Email = '" + email + "'");
                break; // Exit the loop if email is valid
            }
        }
    }

    if (updates.empty()) {
        cout << "No fields to update." << endl;
        return;
    }
    // Append updates to the base update query
    for (size_t i = 0; i < updates.size(); ++i) {
        updateQuery += updates[i];
        if (i < updates.size() - 1) {
            updateQuery += ", ";
        }
    }

    updateQuery += " WHERE CustomerID = '" + customerID + "'";

    if (mysql_query(conn, updateQuery.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
    }
    else {
        cout << "Customer updated successfully!" << endl;
        displayData("customer");
    }
}

// Delete customer
void deleteCustomer() {
    if (currentUserRole != "admin") {
        cout << "Access denied. This function is for admin users only." << endl;
        return;
    }

    string customerID;
    cout << "Enter Customer ID to Delete: ";
    cin >> customerID;

    // Step 1: Delete associated vehicles
    string deleteVehiclesQuery = "DELETE FROM Vehicle WHERE CustomerID = '" + customerID + "'";
    if (mysql_query(conn, deleteVehiclesQuery.c_str())) {
        cerr << "Error: Could not delete vehicles. " << mysql_error(conn) << endl;
        return;
    }

    // Step 2: Delete the customer
    string deleteCustomerQuery = "DELETE FROM Customer WHERE CustomerID = '" + customerID + "'";
    if (mysql_query(conn, deleteCustomerQuery.c_str())) {
        cerr << "Error: Could not delete customer. " << mysql_error(conn) << endl;
    }
    else {
        cout << "Customer and associated vehicles deleted successfully!" << endl;
        displayData("customer");
    }
}

// Search customer by ID
void searchCustomer() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string searchField, searchValue;
    char choice;

    // Menu for selecting fields to search
    cout << "\n===== Select field to search by =====" << endl;
    cout << "a. CustomerID" << endl;
    cout << "b. Name" << endl;
    cout << "c. Address" << endl;
    cout << "d. Phone Number" << endl;
    cout << "e. Email" << endl;
    cout << "Enter your choice (a, b, c, d, e): ";
    cin >> choice;

    // Set the search field based on the user selection
    switch (tolower(choice)) {
    case 'a': searchField = "CustomerID"; break;
    case 'b': searchField = "Name"; break;
    case 'c': searchField = "Address"; break;
    case 'd': searchField = "PhoneNumber"; break;
    case 'e': searchField = "Email"; break;
    default:
        cerr << "Invalid choice." << endl;
        return;
    }

    // Prompt for search value
    cout << "Enter search value for " << searchField << ": ";
    cin.ignore();
    getline(cin, searchValue);


    // Build the dynamic query
    string query = "SELECT * FROM Customer WHERE " + searchField + " LIKE '%" + searchValue + "%'";

    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    // If no rows are returned, show an error message
    if (mysql_num_rows(result) == 0) {
        cout << "Error: No customers found with '" << searchField << "' matching '" << searchValue << "'." << endl;
        mysql_free_result(result);
        return;
    }
    MYSQL_ROW row;
    unsigned int numFields = mysql_num_fields(result);
    MYSQL_FIELD* fields = mysql_fetch_fields(result);

    // Determine column widths
    vector<size_t> colWidths(numFields, 0);
    for (unsigned int i = 0; i < numFields; ++i) {
        colWidths[i] = max(colWidths[i], strlen(fields[i].name)); // Column name length
    }

    while ((row = mysql_fetch_row(result))) {
        for (unsigned int i = 0; i < numFields; ++i) {
            colWidths[i] = max(colWidths[i], row[i] ? strlen(row[i]) : 4); // Length of data or "NULL"
        }
    }
    mysql_data_seek(result, 0); // Reset the result pointer to start


    // Print table header
    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    cout << "|";
    for (unsigned int i = 0; i < numFields; ++i) {
        cout << " " << setw(colWidths[i]) << left << fields[i].name << " |";
    }
    cout << endl;

    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;
    int rowNumber = 1;
    // Print table rows
    while ((row = mysql_fetch_row(result))) {
        cout << "|";
        for (unsigned int i = 0; i < numFields; ++i) {
            string cellValue = (row[i] ? row[i] : "NULL");
            if (cellValue.length() > colWidths[i]) {
                cellValue = cellValue.substr(0, colWidths[i] - 3) + "...";
            }
            cout << " " << setw(colWidths[i]) << left << cellValue << " |";
        }
        cout << endl;
    }

    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;


    // Free the result set
    mysql_free_result(result);
}

// Function to display all customers
void displayAllCustomers() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string query = "SELECT * FROM Customer";  // Query to select all customers
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_ROW row;
    unsigned int numFields = mysql_num_fields(result);
    MYSQL_FIELD* fields = mysql_fetch_fields(result);

    // Determine column widths
    vector<size_t> colWidths(numFields, 0);
    for (unsigned int i = 0; i < numFields; ++i) {
        colWidths[i] = max(colWidths[i], strlen(fields[i].name)); // Column name length
    }

    while ((row = mysql_fetch_row(result))) {
        for (unsigned int i = 0; i < numFields; ++i) {
            colWidths[i] = max(colWidths[i], row[i] ? strlen(row[i]) : 4); // Length of data or "NULL"
        }
    }
    mysql_data_seek(result, 0); // Reset the result pointer to start


    // Print table header
    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    cout << "|";
    for (unsigned int i = 0; i < numFields; ++i) {
        cout << " " << setw(colWidths[i]) << left << fields[i].name << " |";
    }
    cout << endl;

    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    // Print table rows
    while ((row = mysql_fetch_row(result))) {
        cout << "|";
        for (unsigned int i = 0; i < numFields; ++i) {
            string cellValue = (row[i] ? row[i] : "NULL");
            if (cellValue.length() > colWidths[i]) {
                cellValue = cellValue.substr(0, colWidths[i] - 3) + "...";
            }
            cout << " " << setw(colWidths[i]) << left << cellValue << " |";
        }
        cout << endl;
    }

    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    mysql_free_result(result);
}

// Function to validate license plate length
bool isValidLicensePlate(const string& licensePlate) {
    return licensePlate.length() == 7;
}

// Validate VehicleID format ("Veh" followed by exactly 3 digits)
bool isValidVehicleID(const string& vehicleID) {
    const regex vehicleIDPattern(R"(^Vehicle\d{3}$)");  // Matches "Vehicle" followed by exactly 3 digits
    return regex_match(vehicleID, vehicleIDPattern);
}

// Check if VehicleID already exists in the database
bool isDuplicateVehicleID(const string& vehicleID) {
    string query = "SELECT COUNT(*) FROM Vehicle WHERE VehicleID = '" + vehicleID + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    int count = atoi(row[0]); // Get the count of rows with the same VehicleID
    mysql_free_result(result);

    return count > 0; // Return true if a duplicate is found
}

// Check if CustomerID exists in the database
bool isCustomerIDExist(const string& customerID) {
    string query = "SELECT COUNT(*) FROM Customer WHERE CustomerID = '" + customerID + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    int count = atoi(row[0]); // Get the count of rows with the same CustomerID
    mysql_free_result(result);

    return count > 0; // Return true if CustomerID exists
}

// Add vehicle with manual VehicleID input and enhanced validation
void addVehicle() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string vehicleID, customerID, color, typeCar, licensePlate;
    int year;

    // Prompt user for VehicleID with validation
    while (true) {
        cout << "Enter Vehicle ID (example: Vehicle001): ";
        cin >> vehicleID;

        // Validate VehicleID format
        if (!isValidVehicleID(vehicleID)) {
            cerr << "Error: Invalid VehicleID format. It must start with 'Vehicle' followed by exactly 3 digits (e.g., Vehicle001)." << endl;
        }
        else if (isDuplicateVehicleID(vehicleID)) {
            cerr << "Error: VehicleID already exists. Please choose a different ID." << endl;
        }
        else {
            break; // Exit the loop if VehicleID is valid and not a duplicate
        }
    }

    // Prompt user for CustomerID and check if it exists
    while (true) {
        cout << "Enter Customer ID: ";
        cin >> customerID;

        // Check if CustomerID exists in the database
        if (!isCustomerIDExist(customerID)) {
            cerr << "Error: CustomerID does not exist. Please enter a valid CustomerID." << endl;
        }
        else {
            break;  // Exit the loop if CustomerID exists
        }
    }

    cout << "Enter Color: ";
    cin >> color;
    cout << "Enter Type Car: ";
    cin >> typeCar;

    // Validate year input
    while (true) {
        cout << "Enter Year (4 digits): ";
        cin >> year;
        if (to_string(year).length() == 4) {
            break; // Exit the loop if year is valid
        }
        else {
            cout << "Error: Year must be exactly 4 digits. Please try again." << endl;
        }
    }

    // Validate license plate length
    while (true) {
        cout << "Enter License Plate (7 characters): ";
        cin >> licensePlate;
        if (isValidLicensePlate(licensePlate)) {
            break; // Exit the loop if license plate is valid
        }
        else {
            cout << "Error: License Plate must be exactly 7 characters long. Please try again." << endl;
        }
    }

    // Prepare query to insert vehicle into database
    string query = "INSERT INTO Vehicle (VehicleID, CustomerID, Color, TypeCar, Year, LicensePlate) VALUES ('"
        + vehicleID + "', '" + customerID + "', '" + color + "', '" + typeCar + "', " + to_string(year) + ", '"
        + licensePlate + "')";

    // Execute the query
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
    }
    else {
        cout << "Vehicle added successfully!" << endl;
        displayData("vehicle");
    }
}

void updateVehicle() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string vehicleID, color, typeCar, licensePlate;
    int year;
    char choice;

    // Manually enter Vehicle ID
    cout << "Enter Vehicle ID to Update: ";
    cin >> vehicleID;

    // Menu for selecting fields to update
    cout << "\n===== Select fields to update =====" << endl;
    cout << "a. Color" << endl;
    cout << "b. Type Car" << endl;
    cout << "c. Year" << endl;
    cout << "d. License Plate" << endl;
    cout << "Enter your choice (a, b, c, d), or press any other key to skip: ";
    cin >> choice;

    // Collect new values and build the UPDATE query based on user selections
    string updateQuery = "UPDATE Vehicle SET ";
    vector<string> updates;

    if (tolower(choice) == 'a') {
        cout << "Enter New Color: ";
        cin >> color;
        updates.push_back("Color = '" + color + "'");
    }
    if (tolower(choice) == 'b') {
        cout << "Enter New Type Car: ";
        cin >> typeCar;
        updates.push_back("TypeCar = '" + typeCar + "'");
    }
    if (tolower(choice) == 'c') {
        while (true) {
            cout << "Enter New Year: ";
            cin >> year;
            if (to_string(year).length() == 4) {
                updates.push_back("Year = " + to_string(year));
                break; // Exit the loop if year is valid
            }
            else {
                cout << "Error: Year must be exactly 4 digits. Please try again." << endl;
            }
        }
    }
    if (tolower(choice) == 'd') {
        while (true) {
            cout << "Enter New License Plate (7 characters): ";
            cin >> licensePlate;
            if (isValidLicensePlate(licensePlate)) {
                updates.push_back("LicensePlate = '" + licensePlate + "'");
                break; // Exit the loop if license plate is valid
            }
            else {
                cout << "Error: License Plate must be exactly 7 characters long. Please try again." << endl;
            }
        }
    }
    if (updates.empty()) {
        cout << "No fields to update." << endl;
        return;
    }

    // Append updates to the base update query
    for (size_t i = 0; i < updates.size(); ++i) {
        updateQuery += updates[i];
        if (i < updates.size() - 1) {
            updateQuery += ", ";
        }
    }

    updateQuery += " WHERE VehicleID = '" + vehicleID + "'";

    if (mysql_query(conn, updateQuery.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
    }
    else {
        cout << "Vehicle updated successfully!" << endl;
        displayData("vehicle");
    }
}

// Delete vehicle
void deleteVehicle() {
    if (currentUserRole != "admin") {
        cout << "Access denied. This function is for admin users only." << endl;
        return;
    }

    string vehicleID;
    cout << "Enter Vehicle ID to Delete: ";
    cin >> vehicleID;

    string query = "DELETE FROM Vehicle WHERE VehicleID = '" + vehicleID + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
    }
    else {
        cout << "Vehicle deleted successfully!" << endl;
        displayData("vehicle");
    }
}

// Search vehicle by ID and display only the specific row
void searchVehicle() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string searchField, searchValue;
    char choice;

    // Menu for selecting fields to search
    cout << "\n===== Select field to search by =====" << endl;
    cout << "a. VehicleID" << endl;
    cout << "b. CustomerID" << endl;
    cout << "c. Color" << endl;
    cout << "d. TypeCar" << endl;
    cout << "e. Year" << endl;
    cout << "f. LicensePlate" << endl;
    cout << "Enter your choice (a, b, c, d, e, f): ";
    cin >> choice;

    // Set the search field based on the user selection
    switch (tolower(choice)) {
    case 'a': searchField = "VehicleID"; break;
    case 'b': searchField = "CustomerID"; break;
    case 'c': searchField = "Color"; break;
    case 'd': searchField = "TypeCar"; break;
    case 'e': searchField = "Year"; break;
    case 'f': searchField = "LicensePlate"; break;
    default:
        cerr << "Invalid choice." << endl;
        return;
    }

    // Prompt for search value
    cout << "Enter search value for " << searchField << ": ";
    cin.ignore();
    getline(cin, searchValue);


    // Build the dynamic query
    string query = "SELECT * FROM Vehicle WHERE " + searchField + " LIKE '%" + searchValue + "%'";

    // Execute the query
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    // Store the result
    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }
    // If no rows are returned, show an error message
    if (mysql_num_rows(result) == 0) {
        cout << "Error: No vehicles found with '" << searchField << "' matching '" << searchValue << "'." << endl;
        mysql_free_result(result);
        return;
    }

    MYSQL_ROW row;
    unsigned int numFields = mysql_num_fields(result);
    MYSQL_FIELD* fields = mysql_fetch_fields(result);

    // Determine column widths
    vector<size_t> colWidths(numFields, 0);
    for (unsigned int i = 0; i < numFields; ++i) {
        colWidths[i] = max(colWidths[i], strlen(fields[i].name)); // Column name length
    }

    while ((row = mysql_fetch_row(result))) {
        for (unsigned int i = 0; i < numFields; ++i) {
            colWidths[i] = max(colWidths[i], row[i] ? strlen(row[i]) : 4); // Length of data or "NULL"
        }
    }
    mysql_data_seek(result, 0); // Reset the result pointer to start


    // Print table header
    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    cout << "|";
    for (unsigned int i = 0; i < numFields; ++i) {
        cout << " " << setw(colWidths[i]) << left << fields[i].name << " |";
    }
    cout << endl;

    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;
    int rowNumber = 1;
    // Print table rows
    while ((row = mysql_fetch_row(result))) {
        cout << "|";
        for (unsigned int i = 0; i < numFields; ++i) {
            string cellValue = (row[i] ? row[i] : "NULL");
            if (cellValue.length() > colWidths[i]) {
                cellValue = cellValue.substr(0, colWidths[i] - 3) + "...";
            }
            cout << " " << setw(colWidths[i]) << left << cellValue << " |";
        }
        cout << endl;
    }

    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    // Free the result set
    mysql_free_result(result);
}

// Forward declaration of updateTotalMaintenanceCost
void updateTotalMaintenanceCost(const string& vehicleID);

// Validate MaintenanceID format ("Maint" followed by exactly 3 digits)
bool isValidMaintenanceID(const string& maintenanceID) {
    const regex maintenanceIDPattern(R"(^Maint\d{3}$)");  // Matches "Maint" followed by exactly 3 digits
    return regex_match(maintenanceID, maintenanceIDPattern);
}

// Check if MaintenanceID already exists in the database
bool isDuplicateMaintenanceID(const string& maintenanceID) {
    string query = "SELECT COUNT(*) FROM maintenance WHERE MaintenanceID = '" + maintenanceID + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    int count = atoi(row[0]); // Get the count of rows with the same MaintenanceID
    mysql_free_result(result);

    return count > 0; // Return true if a duplicate is found
}

// Helper function to check if VehicleID exists in the database
bool isVehicleIDExist(const string& vehicleID) {
    string query = "SELECT COUNT(*) FROM Vehicle WHERE VehicleID = '" + vehicleID + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    int count = atoi(row[0]); // Get the count of rows with the same VehicleID
    mysql_free_result(result);

    return count > 0; // Return true if VehicleID exists
}

void generateResit(const string& customerID, const string& serviceDate);

// Modified addMaintenance function
// Modified addMaintenance function to prevent duplicate maintenance IDs for the same vehicle and service date
void addMaintenance() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string maintenanceID, vehicleID, serviceType, customerID;
    int quantity;
    double cost;
    char addMore;

    do {
        // Maintenance ID validation
        while (true) {
            cout << "Enter Maintenance ID (e.g., Maint001): ";
            cin >> maintenanceID;

            if (!isValidMaintenanceID(maintenanceID)) {
                cout << "Error: Maintenance ID must be in the format 'MaintXXX' where 'XXX' is a 3-digit number." << endl;
                continue;
            }

            if (isDuplicateMaintenanceID(maintenanceID)) {
                cout << "Error: Maintenance ID already exists. Please enter a different ID." << endl;
                continue;
            }
            break;
        }

        // Vehicle ID validation
        while (true) {
            cout << "Enter Vehicle ID: ";
            cin >> vehicleID;

            if (!isVehicleIDExist(vehicleID)) {
                cout << "Error: Vehicle ID does not exist. Please enter a valid Vehicle ID." << endl;
            }
            else {
                break;
            }
        }

        // Fetch Customer ID for this Vehicle ID
        string query = "SELECT CustomerID FROM vehicle WHERE VehicleID = '" + vehicleID + "'";
        if (mysql_query(conn, query.c_str())) {
            cerr << "Error fetching Customer ID: " << mysql_error(conn) << endl;
            return;
        }

        MYSQL_RES* result = mysql_store_result(conn);
        if (!result) {
            cerr << "Error storing result set: " << mysql_error(conn) << endl;
            return;
        }

        MYSQL_ROW row = mysql_fetch_row(result);
        if (!row) {
            cerr << "Error: No customer found for the given Vehicle ID." << endl;
            mysql_free_result(result);
            return;
        }
        customerID = row[0]; // Extract CustomerID
        mysql_free_result(result);

        cout << "Enter Service Type (e.g., Oil Change, Tyre Replacement, etc.): ";
        cin.ignore();
        getline(cin, serviceType);

        // Get current date for service
        time_t now = time(0);
        tm currentTime;
        localtime_s(&currentTime, &now);

        char dateStr[11];
        strftime(dateStr, sizeof(dateStr), "%Y-%m-%d", &currentTime);
        string serviceDate(dateStr);


        // Get quantity
        while (true) {
            cout << "Enter Quantity: ";
            cin >> quantity;

            if (quantity <= 0) {
                cout << "Error: Quantity must be greater than 0." << endl;
            }
            else {
                break;
            }
        }

        // Get maintenance cost
        cout << "Enter Maintenance Cost/per Unit (RM): ";
        cin >> cost;

        // Insert into database
        query = "INSERT INTO maintenance (MaintenanceID, VehicleID, ServiceDate, ServiceType, Cost, Quantity) VALUES ('"
            + maintenanceID + "', '" + vehicleID + "', '" + serviceDate + "', '" + serviceType + "', " + to_string(cost) + ", " + to_string(quantity) + ")";

        if (mysql_query(conn, query.c_str())) {
            cerr << "Error: " << mysql_error(conn) << endl;
        }
        else {
            cout << "Maintenance record added successfully!" << endl;

            // After successfully adding maintenance, display the resit
            cout << "\nGenerating resit for Customer ID: " << customerID << " on " << serviceDate << ":\n";
            generateResit(customerID, serviceDate); // Call the function with the customerID and serviceDate
        }

        cout << "Do you want to add another maintenance record? (y/n): ";
        cin >> addMore;

    } while (tolower(addMore) == 'y');
}

void displayCustomerMaintenanceRecords(const string& customerID, const string& serviceDate) {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string query = "SELECT m.MaintenanceID, m.VehicleID, v.TypeCar, m.ServiceDate, m.ServiceType, m.Quantity, (m.Cost * m.Quantity) AS TotalCost "
        "FROM maintenance m "
        "JOIN vehicle v ON m.VehicleID = v.VehicleID "
        "WHERE v.CustomerID = '" + customerID + "' AND m.ServiceDate = '" + serviceDate + "' "
        "ORDER BY m.MaintenanceID";

    if (mysql_query(conn, query.c_str())) {
        cerr << "Error fetching maintenance records: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error storing result set: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_ROW row;
    unsigned int numFields = mysql_num_fields(result);
    MYSQL_FIELD* fields = mysql_fetch_fields(result);

    // Determine column widths
    vector<size_t> colWidths(numFields, 0);
    for (unsigned int i = 0; i < numFields; ++i) {
        colWidths[i] = max(colWidths[i], strlen(fields[i].name)); // Column name length
    }

    while ((row = mysql_fetch_row(result))) {
        for (unsigned int i = 0; i < numFields; ++i) {
            colWidths[i] = max(colWidths[i], row[i] ? strlen(row[i]) : 4); // Length of data or "NULL"
        }
    }
    mysql_data_seek(result, 0); // Reset the result pointer to start

    // Table header
    cout << "+---------------+-------------+---------------+------------+-------------+----------+-------------+" << endl;
    cout << "| MaintenanceID |  VehicleID  | Vehicle Type  | ServiceDate | ServiceType | Quantity |  Total Cost |" << endl;
    cout << "+---------------+-------------+---------------+------------+-------------+----------+-------------+" << endl;

    double grandTotal = 0.0; // Variable to store the total cost

    while ((row = mysql_fetch_row(result))) {
        double totalCost = atof(row[6]); // Convert TotalCost to a double
        grandTotal += totalCost; // Accumulate the total cost
        string MaintenanceID = (row[0] ? row[0] : "NULL");
        if (MaintenanceID.length() > 13) {
            MaintenanceID = MaintenanceID.substr(0, 10) + "...";
        }
        string VehicleID = (row[1] ? row[1] : "NULL");
        if (VehicleID.length() > 11) {
            VehicleID = VehicleID.substr(0, 8) + "...";
        }
        string TypeCar = (row[2] ? row[2] : "NULL");
        if (TypeCar.length() > 13) {
            TypeCar = TypeCar.substr(0, 10) + "...";
        }
        string ServiceDate = (row[3] ? row[3] : "NULL");
        if (ServiceDate.length() > 10) {
            ServiceDate = ServiceDate.substr(0, 7) + "...";
        }
        string ServiceType = (row[4] ? row[4] : "NULL");
        if (ServiceType.length() > 11) {
            ServiceType = ServiceType.substr(0, 8) + "...";
        }

        cout << "| " << setw(13) << left << MaintenanceID << " | " // MaintenanceID
            << setw(11) << left << VehicleID << " | "  // VehicleID
            << setw(13) << left << TypeCar << " | " // Vehicle Type
            << setw(10) << left << ServiceDate << " | " // ServiceDate
            << setw(11) << left << ServiceType << " | " // ServiceType
            << setw(8) << right << row[5] << " | " // Quantity
            << "RM " << setw(9) << right << fixed << setprecision(2) << totalCost << " |" << endl;
    }

    cout << "+---------------+-------------+---------------+------------+-------------+----------+-------------+" << endl;

    // Display the grand total
    cout << "| " << setw(67) << left << "Grand Total"
        << "RM " << setw(9) << right << fixed << setprecision(2) << grandTotal << " |" << endl;

    cout << "+-----------------------------------------------------------------------------------+" << endl;

    mysql_free_result(result);
}

// Update total maintenance cost for the vehicle (without updating the Vehicle table)
void updateTotalMaintenanceCost(const string& vehicleID) {
    // Calculate the total maintenance cost for the given vehicle
    string query = "SELECT SUM(Cost) FROM Maintenance WHERE VehicleID = '" + vehicleID + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    if (row && row[0]) {
        // Total maintenance cost
        double someDouble = 123.45; // Example value
        float totalCost = static_cast<float>(someDouble); // Explicit cast to resolve warning

        // Just print the total cost for the vehicle (or you can return it if needed)
        cout << "Total maintenance cost for Vehicle " << vehicleID << " is: " << totalCost << endl;
    }
    else {
        cout << "No maintenance records found for Vehicle " << vehicleID << endl;
    }

    mysql_free_result(result);
}

// Function to calculate and display total maintenance cost for a vehicle
void displayTotalMaintenanceCost() {
    string vehicleID;
    cout << "Enter Vehicle ID to calculate total maintenance cost: ";
    cin >> vehicleID;

    string query = "SELECT SUM(Cost) FROM maintenance WHERE VehicleID = '" + vehicleID + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    if (row && row[0]) {
        double totalCost = atof(row[0]);
        cout << "Total Maintenance Cost for Vehicle ID " << vehicleID << ": RM " << fixed << setprecision(2) << totalCost << endl;
    }
    else {
        cout << "No maintenance records found for Vehicle ID " << vehicleID << endl;
    }

    mysql_free_result(result);
}

// Update maintenance record
void updateMaintenance() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }
     
    string maintenanceID, serviceType;
    int quantity;
    double cost;
    char choice;

    cout << "Enter Maintenance ID to Update: ";
    cin >> maintenanceID;

    // Menu for selecting fields to update
    cout << "\n===== Select fields to update =====" << endl;
    cout << "a. Service Type" << endl;
    cout << "b. Quantity" << endl;
    cout << "c. Cost" << endl;
    cout << "Enter your choice (a, b, c), or press any other key to skip: ";
    cin >> choice;

    // Collect new values and build the UPDATE query based on user selections
    string updateQuery = "UPDATE Maintenance SET ";
    vector<string> updates;
    cin.ignore();

    if (tolower(choice) == 'a') {
        cout << "Enter New Service Type: ";
        getline(cin, serviceType);
        updates.push_back("ServiceType = '" + serviceType + "'");
    }
    if (tolower(choice) == 'b') {
        while (true) {
            cout << "Enter New Quantity: ";
            cin >> quantity;

            if (quantity <= 0) {
                cout << "Error: Quantity must be greater than 0." << endl;
            }
            else {
                updates.push_back("Quantity = " + to_string(quantity));
                break;
            }
        }
    }
    if (tolower(choice) == 'c') {
        cout << "Enter New Cost (RM): ";
        cin >> cost;
        updates.push_back("Cost = " + to_string(cost));
    }

    if (updates.empty()) {
        cout << "No fields to update." << endl;
        return;
    }

    // Append updates to the base update query
    for (size_t i = 0; i < updates.size(); ++i) {
        updateQuery += updates[i];
        if (i < updates.size() - 1) {
            updateQuery += ", ";
        }
    }

    updateQuery += " WHERE MaintenanceID = '" + maintenanceID + "'";
    if (mysql_query(conn, updateQuery.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
    }
    else {
        cout << "Maintenance record updated successfully!" << endl;
        displayData("maintenance");
    }
}

// Delete maintenance record
void deleteMaintenance() {
    if (currentUserRole != "admin") {
        cout << "Access denied. This function is for admin users only." << endl;
        return;
    }

    string maintenanceID;
    cout << "Enter Maintenance ID to Delete: ";
    cin >> maintenanceID;

    string query = "DELETE FROM Maintenance WHERE MaintenanceID = '" + maintenanceID + "'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
    }
    else {
        cout << "Maintenance record deleted successfully!" << endl;
        displayData("maintenance");
    }
}

// Search maintenance by ID and display the specific record
void searchMaintenance() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string searchField, searchValue;
    char choice;

    // Menu for selecting fields to search
    cout << "\n===== Select field to search by =====" << endl;
    cout << "a. MaintenanceID" << endl;
    cout << "b. VehicleID" << endl;
    cout << "c. ServiceDate" << endl;
    cout << "d. ServiceType" << endl;
    cout << "e. Cost" << endl;
    cout << "f. Quantity" << endl;

    cout << "Enter your choice (a, b, c, d, e, f): ";
    cin >> choice;

    // Set the search field based on the user selection
    switch (tolower(choice)) {
    case 'a': searchField = "MaintenanceID"; break;
    case 'b': searchField = "VehicleID"; break;
    case 'c': searchField = "ServiceDate"; break;
    case 'd': searchField = "ServiceType"; break;
    case 'e': searchField = "Cost"; break;
    case 'f': searchField = "Quantity"; break;
    default:
        cerr << "Invalid choice." << endl;
        return;
    }

    // Prompt for search value
    cout << "Enter search value for " << searchField << ": ";
    cin.ignore();
    getline(cin, searchValue);


    // Build the dynamic query
    string query = "SELECT * FROM Maintenance WHERE " + searchField + " LIKE '%" + searchValue + "%'";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    // Store the result
    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error: " << mysql_error(conn) << endl;
        return;
    }

    // If no rows are returned, show an error message
    if (mysql_num_rows(result) == 0) {
        cout << "Error: No maintenance record found with '" << searchField << "' matching '" << searchValue << "'." << endl;
        mysql_free_result(result);
        return;
    }

    MYSQL_ROW row;
    unsigned int numFields = mysql_num_fields(result);
    MYSQL_FIELD* fields = mysql_fetch_fields(result);

    // Determine column widths
    vector<size_t> colWidths(numFields, 0);
    for (unsigned int i = 0; i < numFields; ++i) {
        colWidths[i] = max(colWidths[i], strlen(fields[i].name)); // Column name length
    }

    while ((row = mysql_fetch_row(result))) {
        for (unsigned int i = 0; i < numFields; ++i) {
            colWidths[i] = max(colWidths[i], row[i] ? strlen(row[i]) : 4); // Length of data or "NULL"
        }
    }
    mysql_data_seek(result, 0); // Reset the result pointer to start


    // Print table header
    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    cout << "|";
    for (unsigned int i = 0; i < numFields; ++i) {
        cout << " " << setw(colWidths[i]) << left << fields[i].name << " |";
    }
    cout << endl;

    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    int rowNumber = 1;
    while ((row = mysql_fetch_row(result))) {
        cout << "|";
        for (unsigned int i = 0; i < numFields; ++i) {
            string cellValue = (row[i] ? row[i] : "NULL");
            if (cellValue.length() > colWidths[i]) {
                cellValue = cellValue.substr(0, colWidths[i] - 3) + "...";
            }
            cout << " " << setw(colWidths[i]) << left << cellValue << " |";
        }
        cout << endl;
    }
    cout << "+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    // Free the result set
    mysql_free_result(result);
}

void calculateAndDisplayMaintenanceByDateWithResit() {
    string query = R"(
        SELECT c.CustomerID, c.Name, m.VehicleID, v.TypeCar, m.ServiceDate, m.Cost, m.Quantity, (m.Cost * m.Quantity) AS TotalCost
        FROM maintenance m
        JOIN vehicle v ON m.VehicleID = v.VehicleID
        JOIN customer c ON v.CustomerID = c.CustomerID
        ORDER BY c.CustomerID, m.ServiceDate, m.VehicleID
    )";

    if (mysql_query(conn, query.c_str())) {
        cerr << "Error fetching maintenance costs: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error storing result set: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_ROW row;

    string currentCustomerID = "";
    string currentDate = "";
    double totalCostForDay = 0.0;

    // Fixed column widths
    const int colWidth1 = 20; // VehicleID
    const int colWidth2 = 25; // Vehicle Type
    const int colWidth3 = 15; // Service Date
    const int colWidth4 = 20; // Total Cost

    while ((row = mysql_fetch_row(result))) {
        string CustomerID = row[0];
        string Name = row[1] ? row[1] : "NULL";
        string VehicleID = row[2] ? row[2] : "NULL";
        string TypeCar = row[3] ? row[3] : "NULL";
        string ServiceDate = row[4] ? row[4] : "NULL";
        double TotalCost = row[7] ? atof(row[7]) : 0.0;

        if (currentCustomerID != CustomerID || currentDate != ServiceDate) {
            if (!currentCustomerID.empty()) {
                // Print total cost for the day
                cout << "+--------------------+-------------------------+---------------+--------------------+" << endl;
                cout << "| " << setw(63) << left << "Total Cost for this Resit:"
                    << "RM " << setw(15) << right << fixed << setprecision(2) << totalCostForDay << " |\n";
                cout << "+--------------------+-------------------------+---------------+--------------------+" << endl;
                totalCostForDay = 0.0;
            }

            currentCustomerID = CustomerID;
            currentDate = ServiceDate;

            cout << "\nResit for Customer: " << Name << " (ID: " << CustomerID << ") on " << ServiceDate << endl;
            cout << "+--------------------+-------------------------+---------------+--------------------+" << endl;
            cout << "| VehicleID          | Vehicle Type            | Service Date  | Total Cost         |" << endl;
            cout << "+--------------------+-------------------------+---------------+--------------------+" << endl;
        }

        totalCostForDay += TotalCost;

        cout << "| " << setw(colWidth1 - 1) << left << VehicleID
            << "| " << setw(colWidth2 - 1) << left << TypeCar
            << "| " << setw(colWidth3 - 1) << left << ServiceDate
            << "| RM " << setw(colWidth4 - 4) << right << fixed << setprecision(2) << TotalCost << " |\n";
    }

    if (!currentCustomerID.empty()) {
        // Print final total cost for the last day
        cout << "+--------------------+-------------------------+---------------+--------------------+" << endl;
        cout << "| " << setw(63) << left << "Total Cost for this Resit:"
            << "RM " << setw(15) << right << fixed << setprecision(2) << totalCostForDay << " |\n";
        cout << "+--------------------+-------------------------+---------------+--------------------+" << endl;
    }

    mysql_free_result(result);
}

// Function to display maintenance records in a formatted table
void displayAllMaintenanceRecords() {
    if (currentUserRole != "staff" && currentUserRole != "admin") {
        cout << "Access denied. This function is for staff or admin users only." << endl;
        return;
    }

    string query = "SELECT MaintenanceID, VehicleID, ServiceDate, ServiceType, Cost, Quantity, (Cost * Quantity) AS TotalCost FROM maintenance";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Error fetching maintenance records: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (result == nullptr) {
        cerr << "Error storing result set: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_ROW row;
    unsigned int numFields = mysql_num_fields(result);
    MYSQL_FIELD* fields = mysql_fetch_fields(result);

    // Determine the maximum width for each column
    vector<size_t> colWidths(numFields, 0);
    for (unsigned int i = 0; i < numFields; ++i) {
        colWidths[i] = max(colWidths[i], strlen(fields[i].name)); // Column name length
    }

    while ((row = mysql_fetch_row(result))) {
        for (unsigned int i = 0; i < numFields; ++i) {
            colWidths[i] = max(colWidths[i], row[i] ? strlen(row[i]) : 4); // Length of data or "NULL"
        }
    }
    mysql_data_seek(result, 0); // Reset the result pointer to start

    // Print table header with "No." column
    cout << "+----+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    // Print "No." and column names
    cout << "| No |";
    for (unsigned int i = 0; i < numFields; ++i) {
        cout << " " << setw(colWidths[i]) << left << fields[i].name << " |";
    }
    cout << endl;

    // Print the separator line
    cout << "+----+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    // Fetch and display all rows
    int rowNumber = 1;

    // Display rows
    while ((row = mysql_fetch_row(result))) {
        cout << "| " << setw(2) << rowNumber++ << " |";
        for (unsigned int i = 0; i < numFields; ++i) {
            string cellValue = (row[i] ? row[i] : "NULL");
            if (cellValue.length() > colWidths[i]) {
                cellValue = cellValue.substr(0, colWidths[i] - 3) + "...";
            }
            if (i == numFields - 1) {
                cout << " " << setw(colWidths[i]) << right << cellValue << " |";
            }
            else {
                cout << " " << setw(colWidths[i]) << left << cellValue << " |";
            }
        }
        cout << endl;
    }

    // Print table footer
    cout << "+----+";
    for (size_t width : colWidths) {
        cout << string(width + 2, '-') << "+";
    }
    cout << endl;

    mysql_free_result(result);
}

void generateResit(const string& customerID, const string& serviceDate) {
    string query = "SELECT m.MaintenanceID, m.VehicleID, v.TypeCar, m.ServiceType, m.Quantity, (m.Cost * m.Quantity) AS TotalCost "
        "FROM maintenance m "
        "JOIN vehicle v ON m.VehicleID = v.VehicleID "
        "WHERE v.CustomerID = '" + customerID + "' AND m.ServiceDate = '" + serviceDate + "' "
        "ORDER BY m.MaintenanceID";

    if (mysql_query(conn, query.c_str())) {
        cerr << "Error fetching resit data: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error storing result set: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_ROW row;
    cout << "=========================================== Maintenance Resit =============================================\n";
    cout << "Customer ID: " << customerID << "    Date: " << serviceDate << "\n";
    cout << "-----------------------------------------------------------------------------------------------------------\n";
    cout << "|   MaintenanceID   |   VehicleID   |   Vehicle Type   |   Service Type   |   Quantity   |   Total Cost   |\n";
    cout << "-----------------------------------------------------------------------------------------------------------\n";

    while ((row = mysql_fetch_row(result))) {
        cout << "| " << setw(14) << left << row[0] << " | "
            << setw(9) << left << row[1] << " | "
            << setw(12) << left << row[2] << " | "
            << setw(16) << left << row[3] << " | "
            << setw(8) << left << row[4] << " | "
            << "RM " << setw(8) << right << fixed << setprecision(2) << atof(row[5]) << " |\n";
    }

    cout << "-----------------------------------------------------------------------------------------------------------\n";

    mysql_free_result(result);
}

void generateResits() {
    if (currentUserRole != "admin") {
        cout << "Access denied. This function is for admin users only." << endl;
        return;
    }

    string customerIDChoice;
    cout << "Generate resit for all customers or specific customer? (all/CustID, example: Cust001) ";
    cin >> customerIDChoice;

    string query;
    if (customerIDChoice == "all") {
        query = "SELECT DISTINCT c.CustomerID, m.ServiceDate "
            "FROM maintenance m "
            "JOIN vehicle v ON m.VehicleID = v.VehicleID "
            "JOIN customer c ON v.CustomerID = c.CustomerID "
            "ORDER BY c.CustomerID, m.ServiceDate";
    }
    else if (isValidCustomerID(customerIDChoice)) {
        query = "SELECT DISTINCT c.CustomerID, m.ServiceDate "
            "FROM maintenance m "
            "JOIN vehicle v ON m.VehicleID = v.VehicleID "
            "JOIN customer c ON v.CustomerID = c.CustomerID "
            "WHERE c.CustomerID = '" + customerIDChoice + "' ORDER BY c.CustomerID, m.ServiceDate";
    }
    else {
        cerr << "Error: Invalid CustomerID format or 'all' option. Please try again." << endl;
        return;
    }

    if (mysql_query(conn, query.c_str())) {
        cerr << "Error fetching resits: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_RES* result = mysql_store_result(conn);
    if (!result) {
        cerr << "Error storing result set: " << mysql_error(conn) << endl;
        return;
    }

    MYSQL_ROW row;
    while ((row = mysql_fetch_row(result))) {
        string customerID = row[0];
        string serviceDate = row[1];

        // Print the resit header
        cout << "\n================================================== Maintenance Resit ==================================================\n";
        cout << "Customer ID: " << customerID << "        Date: " << serviceDate << "\n";
        cout << "-----------------------------------------------------------------------------------------------------------------------\n";
        cout << "| MaintenanceID |  VehicleID  | Vehicle Type  | Service Type | Quantity |     Total Cost    |\n";
        cout << "-----------------------------------------------------------------------------------------------------------------------\n";

        // Fetch and display maintenance records for the given customer and date
        string resitQuery = "SELECT m.MaintenanceID, m.VehicleID, v.TypeCar, m.ServiceType, m.Quantity, (m.Cost * m.Quantity) AS TotalCost "
            "FROM maintenance m "
            "JOIN vehicle v ON m.VehicleID = v.VehicleID "
            "WHERE v.CustomerID = '" + customerID + "' AND m.ServiceDate = '" + serviceDate + "' "
            "ORDER BY m.MaintenanceID";

        if (mysql_query(conn, resitQuery.c_str())) {
            cerr << "Error fetching maintenance records for resit: " << mysql_error(conn) << endl;
            continue;
        }

        MYSQL_RES* resitResult = mysql_store_result(conn);
        if (!resitResult) {
            cerr << "Error storing result set for resit: " << mysql_error(conn) << endl;
            continue;
        }

        MYSQL_ROW resitRow;
        double grandTotal = 0.0; // Variable to store the grand total cost

        while ((resitRow = mysql_fetch_row(resitResult))) {
            double totalCost = atof(resitRow[5]); // Convert TotalCost to a double
            grandTotal += totalCost; // Accumulate the total cost

            cout << "| " << setw(13) << left << resitRow[0] << " | "  // MaintenanceID
                << setw(11) << left << resitRow[1] << " | "  // VehicleID
                << setw(13) << left << resitRow[2] << " | "  // Vehicle Type
                << setw(12) << left << resitRow[3] << " | "  // Service Type
                << setw(8) << right << resitRow[4] << " | "  // Quantity
                << "RM " << setw(15) << right << fixed << setprecision(2) << totalCost << " |\n";  // Total Cost
        }

        cout << "-----------------------------------------------------------------------------------------------------------------------\n";

        // Display the grand total
        cout << "| " << setw(66) << left << "Grand Total"
            << "RM " << setw(15) << right << fixed << setprecision(2) << grandTotal << " |\n";
        cout << "-----------------------------------------------------------------------------------------------------------------------\n";

        mysql_free_result(resitResult);
    }

    mysql_free_result(result);
}

void generateReport() {
    if (currentUserRole != "admin") {
        cout << "Access denied. This function is for admin users only." << endl;
        return;
    }

    // Get current time for unique filename (formatted as YYYY-MM-DD_HH-MM-SS)
    time_t now = time(0);
    struct tm timeinfo;
    localtime_s(&timeinfo, &now);
    char timestamp[80];
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d_%H-%M-%S", &timeinfo);

    // Create a unique filename using the timestamp
    string fileName = "report_" + string(timestamp) + ".csv";

    // Open the file in write mode (create a new file for each report)
    ofstream reportFile(fileName);

    if (!reportFile) {
        cerr << "Error: Could not open file for writing!" << endl;
        return;
    }

    reportFile << "========================================================================\n";
    reportFile << "================= Vehicle Maintenance Management System Report =================\n";
    reportFile << "========================================================================\n";

    // Fetch all customers data
    reportFile << "\n---------- All Customers -----------\n";
    reportFile << "CustomerID,Name,Address,PhoneNumber,Email\n";
    string customerQuery = "SELECT CustomerID, Name, Address, PhoneNumber, Email FROM Customer";
    MYSQL_RES* customerResult;
    MYSQL_ROW customerRow;
    if (mysql_query(conn, customerQuery.c_str())) {
        cerr << "Error fetching customers: " << mysql_error(conn) << endl;
    }
    else {
        customerResult = mysql_store_result(conn);
        if (customerResult) {
            while ((customerRow = mysql_fetch_row(customerResult))) {
                reportFile << "\"" << customerRow[0] << "\"," << "\"" << customerRow[1] << "\","
                    << "\"" << customerRow[2] << "\"," << "\"" << customerRow[3] << "\"," << "\"" << customerRow[4] << "\"\n";
            }
            mysql_free_result(customerResult);
        }
    }

    // Fetch all vehicle data
    reportFile << "\n---------- All Vehicles -----------\n";
    reportFile << "VehicleID,CustomerID,Color,TypeCar,Year,LicensePlate\n";
    string vehicleQuery = "SELECT VehicleID, CustomerID, Color, TypeCar, Year, LicensePlate FROM Vehicle";
    MYSQL_RES* vehicleResult;
    MYSQL_ROW vehicleRow;
    if (mysql_query(conn, vehicleQuery.c_str())) {
        cerr << "Error fetching vehicles: " << mysql_error(conn) << endl;
    }
    else {
        vehicleResult = mysql_store_result(conn);
        if (vehicleResult) {
            while ((vehicleRow = mysql_fetch_row(vehicleResult))) {
                reportFile << "\"" << vehicleRow[0] << "\"," << "\"" << vehicleRow[1] << "\"," << "\"" << vehicleRow[2] << "\","
                    << "\"" << vehicleRow[3] << "\"," << "\"" << vehicleRow[4] << "\"," << "\"" << vehicleRow[5] << "\"\n";
            }
            mysql_free_result(vehicleResult);
        }
    }

    // Fetch all maintenance data
    reportFile << "\n---------- All Maintenance Records -----------\n";
    reportFile << "MaintenanceID,VehicleID,ServiceDate,ServiceType,Cost,Quantity,TotalCost\n";
    string maintenanceQuery = "SELECT MaintenanceID, VehicleID, ServiceDate, ServiceType, Cost, Quantity, (Cost * Quantity) AS TotalCost FROM maintenance";
    MYSQL_RES* maintenanceResult;
    MYSQL_ROW maintenanceRow;

    if (mysql_query(conn, maintenanceQuery.c_str())) {
        cerr << "Error fetching maintenance records: " << mysql_error(conn) << endl;
    }
    else {
        maintenanceResult = mysql_store_result(conn);
        if (maintenanceResult) {
            while ((maintenanceRow = mysql_fetch_row(maintenanceResult))) {
                reportFile << "\"" << maintenanceRow[0] << "\","
                    << "\"" << maintenanceRow[1] << "\","
                    << "\"" << maintenanceRow[2] << "\","
                    << "\"" << maintenanceRow[3] << "\","
                    << "\"" << maintenanceRow[4] << "\","
                    << "\"" << maintenanceRow[5] << "\","
                    << "RM " << fixed << setprecision(2) << atof(maintenanceRow[6]) << "\n";
            }
            mysql_free_result(maintenanceResult);
        }
    }

    // Calculate Vehicle Maintenance Frequency
    reportFile << "\n---------- Vehicle Maintenance Frequency -----------\n";
    reportFile << "VehicleID,Maintenance Count\n";
    string vehicleFrequencyQuery = "SELECT VehicleID, COUNT(*) FROM maintenance GROUP BY VehicleID ORDER BY COUNT(*) DESC";
    MYSQL_RES* vehicleFreqResult;
    MYSQL_ROW vehicleFreqRow;
    if (mysql_query(conn, vehicleFrequencyQuery.c_str())) {
        cerr << "Error fetching vehicle frequency data: " << mysql_error(conn) << endl;
    }
    else {
        vehicleFreqResult = mysql_store_result(conn);
        if (vehicleFreqResult) {
            while ((vehicleFreqRow = mysql_fetch_row(vehicleFreqResult))) {
                reportFile << "\"" << vehicleFreqRow[0] << "\"," << "\"" << vehicleFreqRow[1] << "\"\n";
            }
            mysql_free_result(vehicleFreqResult);
        }
    }

    // Calculate Customer Maintenance Frequency
    reportFile << "\n---------- Customer Maintenance Frequency -----------\n";
    reportFile << "CustomerID,Maintenance Count\n";
    string customerFrequencyQuery =
        "SELECT v.CustomerID, COUNT(*) "
        "FROM maintenance m "
        "JOIN vehicle v ON m.VehicleID = v.VehicleID "
        "GROUP BY v.CustomerID ORDER BY COUNT(*) DESC";
    MYSQL_RES* customerFreqResult;
    MYSQL_ROW customerFreqRow;
    if (mysql_query(conn, customerFrequencyQuery.c_str())) {
        cerr << "Error fetching customer frequency data: " << mysql_error(conn) << endl;
    }
    else {
        customerFreqResult = mysql_store_result(conn);
        if (customerFreqResult) {
            while ((customerFreqRow = mysql_fetch_row(customerFreqResult))) {
                reportFile << "\"" << customerFreqRow[0] << "\"," << "\"" << customerFreqRow[1] << "\"\n";
            }
            mysql_free_result(customerFreqResult);
        }
    }

    // Calculate Total Profit by Day
    reportFile << "\n---------- Total Profit by Day -----------\n";
    reportFile << "ServiceDate,Total Profit\n";
    string dailyProfitQuery = "SELECT ServiceDate, SUM(Cost * Quantity) AS DailyProfit FROM maintenance GROUP BY ServiceDate ORDER BY ServiceDate";
    MYSQL_RES* dailyProfitResult;
    MYSQL_ROW dailyProfitRow;
    if (mysql_query(conn, dailyProfitQuery.c_str())) {
        cerr << "Error fetching daily profit: " << mysql_error(conn) << endl;
    }
    else {
        dailyProfitResult = mysql_store_result(conn);
        if (dailyProfitResult) {
            while ((dailyProfitRow = mysql_fetch_row(dailyProfitResult))) {
                reportFile << "\"" << dailyProfitRow[0] << "\",RM " << fixed << setprecision(2) << atof(dailyProfitRow[1]) << "\n";
            }
            mysql_free_result(dailyProfitResult);
        }
    }


    // Calculate Total Profit by Week
    reportFile << "\n---------- Total Profit by Week -----------\n";
    reportFile << "Week Start Date,Total Profit\n";
    string weeklyProfitQuery = "SELECT DATE_FORMAT(ServiceDate, '%Y-%m-%d'), SUM(Cost*Quantity) FROM maintenance GROUP BY YEARWEEK(ServiceDate, 1) ORDER BY YEARWEEK(ServiceDate, 1)";
    MYSQL_RES* weeklyProfitResult;
    MYSQL_ROW weeklyProfitRow;
    if (mysql_query(conn, weeklyProfitQuery.c_str())) {
        cerr << "Error fetching weekly profit: " << mysql_error(conn) << endl;
    }
    else {
        weeklyProfitResult = mysql_store_result(conn);
        if (weeklyProfitResult) {
            while ((weeklyProfitRow = mysql_fetch_row(weeklyProfitResult))) {
                reportFile << "\"" << weeklyProfitRow[0] << "\",RM " << fixed << setprecision(2) << atof(weeklyProfitRow[1]) << "\n";
            }
            mysql_free_result(weeklyProfitResult);
        }
    }

    // Calculate Total Profit by Month
    reportFile << "\n---------- Total Profit by Month -----------\n";
    reportFile << "Month,Total Profit\n";
    string monthlyProfitQuery = "SELECT DATE_FORMAT(ServiceDate, '%Y-%m'), SUM(Cost * Quantity) AS MonthlyProfit FROM maintenance GROUP BY DATE_FORMAT(ServiceDate, '%Y-%m') ORDER BY DATE_FORMAT(ServiceDate, '%Y-%m')";
    MYSQL_RES* monthlyProfitResult;
    MYSQL_ROW monthlyProfitRow;
    if (mysql_query(conn, monthlyProfitQuery.c_str())) {
        cerr << "Error fetching monthly profit: " << mysql_error(conn) << endl;
    }
    else {
        monthlyProfitResult = mysql_store_result(conn);
        if (monthlyProfitResult) {
            while ((monthlyProfitRow = mysql_fetch_row(monthlyProfitResult))) {
                reportFile << "\"" << monthlyProfitRow[0] << "\",RM " << fixed << setprecision(2) << atof(monthlyProfitRow[1]) << "\n";
            }
            mysql_free_result(monthlyProfitResult);
        }
    }

    // Close the file
    reportFile.close();

    cout << "Report generated successfully and saved to " << fileName << endl;
}

// Menu display
void menu();
void accountMenu();  // Forward declaration for accountMenu
void customerMenu();
void vehicleMenu();
void maintenanceMenu();

// Main menu
void menu() {
    int choice;
    while (true) {
        cout << "\n===== VEHICLE MAINTENANCE MANAGEMENT SYSTEM =====\n" << endl;
        cout << "---------------------------------------------------\n" << endl;
        cout << "1. Customer Management" << endl;
        cout << "2. Vehicle Management" << endl;
        cout << "3. Maintenance Management" << endl;
        if (currentUserRole == "admin") {
            cout << "4. Generate Report" << endl;
            cout << "5. Generate Resit" << endl;
            cout << "6. Account Management" << endl;
        }
        cout << "9. Back to Welcome Screen" << endl;
        cout << "0. Exit" << endl;
        cout << "---------------------------------------------------\n" << endl;
        cout << "Select an option: ";
        // Validate integer input
        if (!(cin >> choice)) {
            cerr << "Error: Invalid input. Please enter a number." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue; // Jump back to the start of the loop
        }
        switch (choice) {
        case 1:
            system("cls");
            customerMenu(); break;
        case 2:
            system("cls");
            vehicleMenu(); break;
        case 3:
            system("cls");
            maintenanceMenu(); break;
        case 4:
            if (currentUserRole == "admin") {
                generateReport();
            }
            else {
                cerr << "Invalid option, please try again!" << endl;
            }
            break;
        case 5:
            if (currentUserRole == "admin") {
                generateResits();
            }
            else {
                cerr << "Invalid option, please try again!" << endl;
            }
            break;
        case 6:
            if (currentUserRole == "admin") {
                system("cls");
                accountMenu();
            }
            else {
                cerr << "Invalid option, please try again!" << endl;
            }
            break;
        case 9:
            system("cls");
            return;
        case 0:
            exit(0);
        default: cerr << "Invalid option, please try again!" << endl;
        }
    }
}

void accountMenu() {
    int choice;
    while (true) {
        cout << "\n---------------------------------\n";
        cout << "\n====== Account Management ======\n" << endl;
        cout << "\n---------------------------------\n";
        cout << "1. Add User" << endl;
        cout << "2. Update User" << endl;
        cout << "3. Delete User" << endl;
        cout << "4. Display All User" << endl;
        cout << "0. Back to Main Menu" << endl;
        cout << "Select an option: ";
        cin >> choice;
        switch (choice) {
        case 1: addUser(); break;
        case 2: updateUser(); break;
        case 3: deleteUser(); break;
        case 4: displayAllUsers(); break;
        case 0: system("cls");
            return; // Back to main menu
        default: cerr << "Invalid option, please try again!" << endl;
        }
    }
}

void customerMenu() {
    int choice;
    while (true) {
        cout << "\n---------------------------------\n";
        cout << "\n====== Customer Management ======\n" << endl;
        cout << "\n---------------------------------\n";
        cout << "1. Add Customer" << endl;
        cout << "2. Update Customer" << endl;
        cout << "3. Search Customer" << endl;
        if (currentUserRole == "admin") {
            cout << "4. Delete Customer" << endl;
        }
        cout << "5. Display All Customers" << endl;
        cout << "0. Back to Main Menu" << endl;
        cout << "Select an option: ";
        cin >> choice;
        switch (choice) {
        case 1: addCustomer(); break;
        case 2: updateCustomer(); break;
        case 3: searchCustomer(); break;
        case 4:
            if (currentUserRole == "admin") {
                deleteCustomer();
            }
            else {
                cerr << "Invalid option, please try again!" << endl;
            }
            break;
        case 5: displayAllCustomers(); break;
        case 0: system("cls");
            return; // Back to main menu
        default: cerr << "Invalid option, please try again!" << endl;
        }
    }
}

void vehicleMenu() {
    int choice;
    while (true) {
        cout << "\n--------------------------------\n";
        cout << "\n====== Vehicle Management ======\n" << endl;
        cout << "\n--------------------------------\n";
        cout << "1. Add Vehicle" << endl;
        cout << "2. Update Vehicle" << endl;
        cout << "3. Search Vehicle" << endl;
        if (currentUserRole == "admin") {
            cout << "4. Delete Vehicle" << endl;
        }
        cout << "5. Display All Vehicles" << endl;
        cout << "0. Back to Main Menu" << endl;
        cout << "Select an option: ";
        cin >> choice;
        switch (choice) {
        case 1: addVehicle(); break;
        case 2: updateVehicle(); break;
        case 3: searchVehicle(); break;
        case 4:
            if (currentUserRole == "admin") {
                deleteVehicle();
            }
            else {
                cerr << "Invalid option, please try again!" << endl;
            }
            break;
        case 5: displayData("vehicle"); break;
        case 0:
            system("cls");
            return; // Back to main menu
        default: cerr << "Invalid option, please try again!" << endl;
        }
    }
}

void maintenanceMenu() {
    int choice;
    while (true) {
        cout << "\n--------------------------------------------------------------\n";
        cout << "\n=================== Maintenance Management ===================\n" << endl;
        cout << "\n--------------------------------------------------------------\n";
        cout << "1. Add Maintenance Record" << endl;
        cout << "2. Update Maintenance Record" << endl;
        cout << "3. Search Maintenance Record" << endl;
        if (currentUserRole == "admin") {
            cout << "4. Delete Maintenance Record" << endl;
        }
        cout << "5. Display All Maintenance Records" << endl;
        cout << "\n--------------------------------------------------------------\n";
        cout << "6. Display Customer Maintenance Records" << endl;
        cout << "7. Calculate and Display Maintenance Costs by Date with resit" << endl;
        cout << "8. Generate Resit" << endl;
        cout << "0. Back to Main Menu" << endl;
        cout << "Select an option: ";
        cin >> choice;
        switch (choice) {
        case 1: addMaintenance(); break;
        case 2: updateMaintenance(); break;
        case 3: searchMaintenance(); break;
        case 4:
            if (currentUserRole == "admin") {
                deleteMaintenance();
            }
            else {
                cerr << "Invalid option, please try again!" << endl;
            }
            break;
        case 5: displayAllMaintenanceRecords(); break;
        case 6: {
            string customerID, serviceDate;

            // Prompt the user for Customer ID
            cout << "Enter Customer ID: ";
            cin >> customerID;

            // Prompt the user for Service Date
            cout << "Enter Service Date (YYYY-MM-DD): ";
            cin >> serviceDate;

            // Call the function with the provided inputs
            displayCustomerMaintenanceRecords(customerID, serviceDate);
            break;
        }
        case 7: calculateAndDisplayMaintenanceByDateWithResit(); break;
        case 8: generateResits(); break;
        case 0:
            system("cls");
            return; // Back to main menu
        default: cerr << "Invalid option, please try again!" << endl;
        }
    }
}

int main() {
    connectDatabase();

    // Set the console title (Windows specific)
    const char* title = "Vehicle Maintenance Management System";
    int titleLength = MultiByteToWideChar(CP_ACP, 0, title, -1, nullptr, 0);
    WCHAR* wideTitle = new WCHAR[titleLength];
    MultiByteToWideChar(CP_ACP, 0, title, -1, wideTitle, titleLength);
    SetConsoleTitle(wideTitle);
    delete[] wideTitle;

    // Initial welcome screen loop
    char choice;
    string userType;

    cout << "\n----------------------------------------------------------\n";
    cout << "==== WELCOME TO VEHICLE MAINTENANCE MANAGEMENT SYSTEM ====\n";
    cout << "----------------------------------------------------------\n";
    cout << "This system allows you to manage customers, vehicles and\n";
    cout << "maintenance records. If you have an admin account you can \n";
    cout << "manage all aspects of the system. If you are a staff, then \n";
    cout << "you are limited to viewing, adding and editing specific \n";
    cout << "items.\n";
    cout << "----------------------------------------------------------\n";
    while (true) {
        while (true) {
            cout << "Are you logging in as a (staff or admin)? ";
            cin >> userType;

            if (userType == "staff" || userType == "admin") {
                break;
            }
            else {
                cerr << "Invalid input. Please enter 'staff' or 'admin'." << endl;
            }
        }

        if (userType == "staff") {
            // Normal sign-up or log-in process (always available)
            while (true)
            {
                cout << "Do you have an account? (y/n): ";
                cin >> choice;
                if (tolower(choice) == 'n')
                {
                    if (!signUp())
                    {
                        continue; // If signup fails, loop to ask again
                    }
                    else
                    {
                        system("cls"); // Clear screen after successful signup
                        break;
                    }
                }
                else if (tolower(choice) == 'y')
                {
                    system("cls"); // Clear screen before asking log in
                    break;
                }
                else
                {
                    cerr << "Invalid input. Please enter 'y' or 'n'." << endl;
                }
            }
        }

        // Require login
        while (!login()) {
            // Loop until successful login
        }

        system("cls");  // Clear the console after successful login
        menu(); // Call the main menu
    }

    return 0;
}

